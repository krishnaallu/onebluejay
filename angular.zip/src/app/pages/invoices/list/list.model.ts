export interface InvoiceList {
  index: number;
  name: string;
  id: string;
  date: string;
  amount: string;
  status: string;
}
