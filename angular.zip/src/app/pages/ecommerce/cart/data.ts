const cartData = [
    {
        image: 'assets/images/product/img-1.png',
        name: 'Nike N012 Running Shoes',
        color: 'Gray',
        size: '08',
        price: '$260',
        quantity: 2,
        total: '$520'
    },
    {
        image: 'assets/images/product/img-2.png',
        name: 'Adidas Running Shoes',
        color: 'Black',
        size: '09',
        price: '$260',
        quantity: 1,
        total: '$260'
    }
];

export { cartData };
