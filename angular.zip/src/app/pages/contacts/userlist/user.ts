export interface User {
    id: string;
    name: string;
    image?: string;
    position: string;
    email: string;
    index: number;
  }