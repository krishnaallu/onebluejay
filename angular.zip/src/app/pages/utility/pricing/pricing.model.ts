export interface Pricing {
    name: string;
    text: string;
    icon: string;
    price: number;
}
